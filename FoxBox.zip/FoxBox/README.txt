------------------------
-----SETUP GUIDE--------
------------------------
1) Extract FoxBox into myDocuments folder
2) Run FoxBox.exe